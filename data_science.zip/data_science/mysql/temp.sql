desc customer;
select * from customer;