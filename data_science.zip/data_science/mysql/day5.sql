use student_management;
select * from students;
select * from students
where stu_age=24;

-- distinct
select distinct stu_age from students;
-- sub query(nested query)
select * from students where stu_age in (select distinct stu_age from students);

-- aggrigate function
select count(*) as total_data from students;
select sum(stu_age) total_age from students;
select avg(stu_age) total_age from students;
select min(stu_age) total_age from students;
select max(stu_age) total_age from students;

-- waq to list the full record of entity which holds maximum age in the table
select * from  students
where stu_age=(select max(stu_age) from students);
select * from  students
where stu_age=(select min(stu_age) from students);