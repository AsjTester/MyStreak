use bank;
select * from customer
where balance= (select max(balance) from customer);
select * from customer
where total_transactions= (select max(total_transactions) from customer);
select * from customer
where balance>(select avg(balance) from customer);
select name,balance from customer
where balance<(select avg(balance) from customer);

-- order by
select * from customer
order by customer_id desc limit 5;
select * from customer
order by loan_amount desc limit 3 ;