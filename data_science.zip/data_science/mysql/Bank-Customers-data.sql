
use bank;
CREATE TABLE Customer(
    Customer_id INT PRIMARY KEY AUTO_INCREMENT,
    Account_number INT UNIQUE,
    Name VARCHAR(50) NOT NULL,
    City VARCHAR(50),
    Account_type VARCHAR(20),
    Balance DECIMAL(15, 2) DEFAULT 0.00, 
    Branch VARCHAR(50),
    Loan_amount DECIMAL(15, 2) DEFAULT 0.00, 
    Total_transactions INT DEFAULT 0, 
    Last_transaction_method VARCHAR(50),
    KYC_status ENUM('Pending', 'Verified', 'Rejected') DEFAULT 'Pending', 
    KYC_type ENUM('Aadhar', 'Passport', 'Driving License', 'Voter ID')     DEFAULT 'Aadhar',
    Occupation VARCHAR(50),
    Tax_ID VARCHAR(20)
);
INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20001, 'Dev Patel', 'Delhi', 'Savings', 26000.00, 'FC Road Branch', 12000.00, 3, 'UPI', 'Verified', 'Aadhar', 'Developer', 'DEV20001');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20002, 'Rhea Singh', 'Mumbai', 'Current', 52000.00, 'Bandra Branch', 0.00, 2, 'Net Banking', 'Pending', 'Passport', 'Designer', 'RHE20002');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20003, 'Arun Rao', 'Hyderabad', 'Savings', 18000.00, 'Begumpet Branch', 8000.00, 4, 'CASH', 'Verified', 'Driving License', 'Teacher', 'ARU20003');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20004, 'Neha Gupta', 'Bengaluru', 'Savings', 34000.50, 'Whitefield Branch', 15000.00, 5, 'Debit Card', 'Verified', 'Voter ID', 'Engineer', 'NEH20004');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20005, 'Karan Shah', 'Ahmedabad', 'Savings', 22000.00, 'Navrangpura Branch', 10000.00, 2, 'UPI', 'Pending', 'Aadhar', 'Manager', 'KAR20005');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20006, 'Priya Mehta', 'Pune', 'Current', 41000.00, 'FC Road Branch', 25000.00, 6, 'Net Banking', 'Verified', 'Passport', 'Consultant', 'PRI20006');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20007, 'Vikram Iyer', 'Chennai', 'Savings', 19500.00, 'T Nagar Branch', 5000.00, 1, 'Cash', 'Pending', 'Driving License', 'Sales Executive', 'VIK20007');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20008, 'Anita Desai', 'Surat', 'Current', 30000.00, 'Ring Road Branch', 0.00, 3, 'UPI', 'Verified', 'Voter ID', 'Accountant', 'ANI20008');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20009, 'Rahul Verma', 'Kochi', 'Savings', 28000.00, 'MG Road Branch', 12000.00, 4, 'Debit Card', 'Verified', 'Aadhar', 'Architect', 'RAH20009');

INSERT INTO Customer (
  Account_number, Name, City, Account_type, Balance, Branch,
  Loan_amount, Total_transactions, Last_transaction_method,
  KYC_status, KYC_type, Occupation, Tax_ID
) VALUES (20010, 'Sanya Kapoor', 'Hyderabad', 'Current', 36000.00, 'Hitech City Branch', 15000.00, 5, 'Net Banking', 'Rejected', 'Passport', 'Lawyer', 'SAN20010');
