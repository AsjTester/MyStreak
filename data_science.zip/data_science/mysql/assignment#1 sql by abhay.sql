create database Student_management;
show databases;
use Student_management;
create table students(
stu_id tinyint primary key auto_increment,
stu_roll_no varchar(10) not null unique,
stu_full_name varchar(100) not null,
stu_age tinyint,
stu_email varchar(100) unique,
stu_phone varchar(10) unique not null,
stu_dob date,
stu_gender enum('m','f','o'),
stu_address varchar(20) default('delhi'),
stu_admission_date date
);
delete from students where stu_age<18;
alter table students add constraint chk_1 check(stu_age>=18);
desc students;
drop table students;
insert into students(stu_roll_no,stu_full_name,stu_age,stu_email,stu_phone,stu_dob,stu_gender,stu_address,stu_admission_date) 
values
('iq123','chotu',17,'jaiswalabhay517@gmail.com','7518009398','2002-09-15','m','mankapur,gonda,up','2025-12-28');

show tables;

insert into students (stu_roll_no,stu_full_name,stu_age,stu_email,stu_phone,stu_dob,stu_gender,stu_admission_date) 
values
('iq102','tarun',23,'bansaktarun517@gmail.com','7845964545','2001-02-15','m','2025-12-28'),
('iq103','prerana',28,'prerana6565@gmail.com','7518829398','1998-09-15','f','2025-12-28'),
('iq104','atul',24,'atul517@gmail.com','7518789398','2002-09-15','m','2025-12-28'),
('iq105','prachi',24,'prachi517@gmail.com','7578009398','2002-09-15','f','2025-12-28'),
('iq106','saloni',24,'saloni78517@gmail.com',7578109398,'2002-09-15','f','2025-12-28'),
('iq107','govinda',24,'dolagovinda517@gmail.com',7568009398,'2002-09-15','m','2025-12-28'),
('iq108','karan',24,'karan517@gmail.com',7518007398,'2002-09-15','m','2025-12-28'),
('iq109','amit',24,'amit517@gmail.com',7518009378,'2002-09-15','m','2025-12-28'),
('iq110','omm',24,'om517@gmail.com',7518003398,'2002-09-15','m','2025-12-28');

insert into students(stu_roll_no,stu_full_name,stu_age,stu_phone,stu_dob,stu_gender,stu_address,stu_admission_date) 
values
('iq112','abhay1',24,7508909398,'2002-09-15','m','mankapur,gonda,up','2025-12-28');
select * from students;