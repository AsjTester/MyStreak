-- Data Types in MySQL
# 1.Number Data Types
-- tinyint :1bytes -128 to 127
-- smallint:2bytes -32,768 to 32,768
-- mediumint:3bytes -8M to 8M
-- int:4bytes -2B to 2B
-- bigint:8bytes very large
-- decimal(p=precision,s=scale): exact number
-- float : approximate, scientific calcalution
-- double : higher precision float
   -- salary decimal(5,2)
# 2.string(text) Data Types
-- char(n) 255 fixed length
-- varchar(n) 65,535 default trext
-- tinytext 255 Bytes
-- text 64KB
-- mediumtext 16MB
-- longtext 4GB
# 3. date and time data types
-- data format: yyyy-mm-dd
-- time format: hh:mm:ss
-- datatime format: yyyy-mm-dd hh:mm:ss
-- year format: yyyy
  -- dob date() --> 2003-03-05
# 4. boolean
-- boolean(0=false,1=true)
# enum and set
-- enum : one value from list
-- set : multiple values
# 6.binary data types
-- binary
-- varbinary
-- tinyblob 
-- blob 64KB
-- mediumblob 16MB
-- longblob 4GB
# constant
-- null
-- not null
-- default
-- primary key auto increment
-- foreign key
-- check
-- unique