create database abhay;
show databases;
select database();
use abhay;
show tables;
create table info (
id int primary key auto_increment ,
roll_no int unique,
name varchar(25) not null,
address varchar(50) default('delhi'),
mobile varchar(13) unique,
dob date,
admission_time datetime,
gender enum('f','m','o'),
age int,
check(age>=18)
);
drop database sakila;
drop table info;
desc info;
insert into info (roll_no,name,address,mobile,dob,admission_time,gender,age)
values(1,"abhay","up","+917518009398","2002-09-15",now(), 'm',24);

insert into info (roll_no,name,mobile,dob,admission_time,gender,age)
values(2,"prachi","+917518079398","2002-09-15",now(), 'f',24);

insert into info (roll_no,name,address,dob,admission_time,gender,age)
values(9,"aman","up","2002-09-15","2026-01-13 14:44:30", 'm',24);

insert into info (roll_no,name,address,mobile,dob,admission_time,gender,age)
values(5,"rohit","up","+917517009398","2002-09-15",now(), 'm',24);

insert into info (roll_no,name,address,mobile,dob,admission_time,gender,age)
values(51,"rohit1","up","+917527009398","2002-09-15",now(), 'm',18);
select *from info;

