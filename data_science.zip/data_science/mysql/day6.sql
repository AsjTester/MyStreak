use abhay;
-- child table
create table customer(
id int auto_increment primary key,
name varchar(50) not null,
Age int, 
cus_city int,
foreign key (cus_city) references city(city_id)
);
-- parent table
create table city(
city varchar(50) not null, 
city_id int primary key
);
insert into city
values
('mumbai',3),
('delhi',2),
('agra',5);
select * from city;
insert into customer(name,age,cus_city)
values
('abhay',24,5);
insert into customer(name,age,cus_city)
values
('prerena',28,2);
select * from customer ;
select * from customer as c join city as ci on c.cus_city=ci.city_id;