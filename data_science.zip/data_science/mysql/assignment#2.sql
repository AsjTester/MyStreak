-- Round 1 — READ (SELECT)
-- 1. Write a query to return all columns for customers from Delhi with Savings accounts and
-- KYC_status set to Verified.
select * from customer
where city='delhi' and account_type='savings' and kyc_status='verified';

-- 2. Write a query to return all columns for customers with Account_type set to Current at
-- Bandra Branch.
select * from customer
where account_type='current' and branch='bandra branch';
-- 3. Write a query to return Name, City, Balance, Loan_amount for customers whose
-- Balance is above 30000.00 and whose Loan_amount is exactly 0.00.
select name,city,balance,loan_amount
from customer
where balance>30000.00 and loan_amount=0.00;
-- 4. Write a query to return all columns for customers whose Balance falls in the inclusive
-- range 20000.00 to 40000.00.
select * from customer
where balance between 20000.00 and 40000.00; 
-- 5. Write a query to return all columns for customers whose Loan_amount is above 0 and
-- whose Balance is smaller than Loan_amount.
select * from customer
where loan_amount>0 and balance<loan_amount;
-- 6. Write a query to return all columns for customers whose Name starts with “A”.
select * from customer
where name like "A%";

-- 7. Write a query to return all columns for customers whose City ends with “i”.
select * from customer
where city like "%i";
-- 8. Write a query to return all columns for customers whose Branch contains the word
-- “Road”.
select * from customer
where branch like "%Road%";
-- 9. Write a query to return all columns for customers whose Occupation contains “Manager”.
select * from customer
where occupation like "%Manager%";
-- 10. Write a query to return all columns for customers where KYC_type is either “Aadhar” or
-- “Passport”, and KYC_status is anything other than “Rejected”.
select * from customer
where kyc_type in ("aadhar","Passport") and kyc_status<>"Rejected";
-- 11. Write a query to return all columns for customers whose City is one of Delhi, Mumbai, or
-- Chennai, with Account_type set to “Savings”.
select * from customer
where city in ('delhi','Mumbai','Chennai') and account_type='Savings';
-- 12. Write a query to return all columns for customers from cities other than Hyderabad and
-- Kochi.
select * from customer
where city not in ('Hyderabad','Kochi');

-- 13. Write a query to return all columns for customers whose Last_transaction_method ends
-- with “Card”.
select * from customer
where last_transaction_method like "%card";
-- 14. Write a query to return all columns for customers whose Name has “a” as the second
-- character.
select * from customer
where name like "_a%";
-- 15. Write a query to return all columns for customers who meet at least one of these
-- conditions: Balance is 30000.00 or more; Loan_amount is 60000.00 or more.
select * from customer
where balance>=30000.00 or loan_amount>=60000.00;
-- 16. Write a query to return all columns for customers with an Account_type other than
-- “Savings”.
select * from customer
where account_type<>'Savings';
-- 17. Write a query to return all columns for customers at FC Road Branch or Ring Road
-- Branch whose KYC_status is Pending.
select * from customer
where kyc_status='pending' and branch in('fc road branch','ring road branch');
-- 18. Write a query to return all columns for customers whose Name does not contain the
-- letter “a”.
select * from customer
where name not like "%a%";
-- 19. Write a query to return all columns for customers with KYC_status set to Verified and
-- KYC_type other than “Voter ID” and “Driving License”.
select * from customer
where kyc_status='verified'and kyc_type not in ('Voter ID','Driving License');
-- 20. Write a query to return all columns for customers whose City begins with “B” and whose
-- Account_type is “Current”.
select * from customer
where city like "B%" and account_type='Current';