create database batch_100;
use batch_100;
create table students(
stu_id int,
stu_name varchar(100),
stu_age int,
stu_marks int
);
select * from students; -- show data in table
desc students; -- description of table
show tables; -- show tables in curr db

-- create table staff(
-- staff_id int,
-- staff_name varchar(100),
-- staff_age int,
-- staff_addr varchar(100)
-- );
-- desc staff;
-- show tables;

-- drop table staff;
insert into students(stu_id,stu_name,stu_marks,stu_age)
values
(1,"aman",50,23), 
(2,"shivam",30,24),
(3,"rohan",20,23),
(4,"riya",30,23);

select * from students;
select * from students where stu_id=1;
select * from students where stu_marks>=30;

-- constraints
drop table students;

create table students(
stu_id int primary key,
stu_name varchar(100),
stu_age int check(stu_age>18),
stu_marks int
);
